module.exports = {
  parserOptions: { ecmaVersion: 6 },
  plugins: ["prettier"],
  rules: {
    "prettier/prettier": "error"
  },
  extends: ["prettier"]
};
